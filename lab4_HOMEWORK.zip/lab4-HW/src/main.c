#include "Gpio.h"
#include "Rcc.h"
#include "Std_Types.h"

#define TRUE				1
#define FALSE				0

void initialize_LEDs(void);
void initialize_button(void);
void initialize(void);
void delay(unsigned int milliseconds);

int main(void){

	initialize();
	uint8 btnState = 0;
	unsigned char prevBtnState = 0;
	unsigned int active_pin = 0;

	while (TRUE)
	{
		// read button
		btnState = Gpio_ReadPin(GPIO_B, 3);
		// detect falling edge (button press)
		if(prevBtnState && !btnState){
			// code for changing color of the LED
			Gpio_WritePin(GPIO_B, 5, LOW);
			Gpio_WritePin(GPIO_B, 6, LOW);
			Gpio_WritePin(GPIO_B, 7, LOW);

			if (active_pin & (0x01)){
				Gpio_WritePin(GPIO_B, 5, HIGH);
			}
			if ((active_pin & (0x01 << 1)) >> 1){
				Gpio_WritePin(GPIO_B, 6, HIGH);
			}
			if ((active_pin & (0x01 << 2)) >> 2){
				Gpio_WritePin(GPIO_B, 7, HIGH);
			}

			active_pin %= 8 ;
			active_pin++;

		}
		// update prev state
		prevBtnState = btnState;
		// add delay for debouncing
		delay(1000);
	}

	return 0;
}

void initialize_LEDs(void){
	for (unsigned int i = 5; i < 8; i++){
		Gpio_ConfigPin(GPIO_B, i, GPIO_OUTPUT, GPIO_PUSH_PULL);
	}
}

void initialize_button(void){
	Gpio_ConfigPin(GPIO_B, 3, GPIO_INPUT, GPIO_PUSH_PULL);
}
void initialize(void){
	Rcc_Init();
	Rcc_Enable(RCC_GPIOB);
	initialize_LEDs();
	initialize_button();
}
void delay(unsigned int milliseconds){
	for (unsigned int i = 0; i < milliseconds; i++){
        __asm("nop");
    }
}

